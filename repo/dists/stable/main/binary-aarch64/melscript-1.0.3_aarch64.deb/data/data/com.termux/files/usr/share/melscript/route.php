<?php
// Define o diretório base onde o script do MelScript está localizado
$melScriptDir = __DIR__; // Diretório onde está o route.php
$scriptToInject = '<script src="https://mel-script.vercel.app/Rec/1.0.3.js"></script>';

// Função para carregar e injetar o script no conteúdo
function loadAndInject($filePath, $script) {
    // Verifica se o arquivo existe
    if (file_exists($filePath)) {
        // Começa a captura da saída
        ob_start();

        // Inclui o arquivo para executar seu conteúdo
        include($filePath);

        // Obtém o conteúdo do buffer
        $content = ob_get_clean();

        // Injetar o script no início do conteúdo
        $content = $script . $content;

        // Envia o conteúdo modificado para o usuário
        echo $content;
    } else {
        // Se o arquivo não existir, envia uma mensagem de erro
        header("HTTP/1.0 404 Not Found");
        echo "Arquivo não encontrado.";
    }
}

// Obtém o caminho do arquivo solicitado
$requestPath = $_SERVER['REQUEST_URI'];

// Define o caminho completo para o arquivo HTML ou PHP usando o diretório atual de execução
$currentDir = getcwd(); // Diretório atual onde o comando foi executado
$filePath = $currentDir . $requestPath;

// Se o arquivo não tiver uma extensão, assume que é um HTML padrão
if (pathinfo($filePath, PATHINFO_EXTENSION) === '') {
    $filePath .= '.html'; // ou '.php', dependendo da sua configuração
}

// Chamando a função para carregar e injetar o script
loadAndInject($filePath, $scriptToInject);
?>
